from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import StudentRegistration
from .models import User
def add_show(request):
    if request.method == "POST":
        fm = StudentRegistration(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            psw = fm.cleaned_data['password']
            
            reg = User(name=nm , email=em, password = psw)
            reg.save()
            fm = StudentRegistration()

    else:
        fm = StudentRegistration()
    stud = User.objects.all()
    return render(request,"enroll/addandshow.html",{"form":fm, "stu":stud})
# Create your views here.

def update_data(request,my_id):
    if request.method == 'POST':
        print("Hii Me update ke andar hu ")
        pi = User.objects.get(pk=my_id)
        fm = StudentRegistration(request.POST, instance=pi)
        print(pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = User.objects.get(pk=my_id)
        fm = StudentRegistration(instance=pi)
    return render(request, "enroll/updatestudent.html", {"form":fm})

def delete_data(request,my_id):
    if request.method == "POST":
        pi = User.objects.get(pk=my_id)
        pi.delete()
        return HttpResponseRedirect('/')




